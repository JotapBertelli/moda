function toggleMenu() {
    const sidebar = document.getElementById('sidebarMenu');
    sidebar.classList.toggle('show');
}
